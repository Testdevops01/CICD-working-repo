#!/bin/bash
echo "Starting dependency installation..."

# Update package list
apt-get update

# Install nginx
apt-get install -y nginx

# Create destination directory
mkdir -p /var/www/html

echo "Dependency installation completed successfully!"
